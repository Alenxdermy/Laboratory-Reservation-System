<template>
	<div>
		<common-header-vue @create="createOrder" title="订单管理界面"></common-header-vue>
		这个是订单页面
	</div>
</template>

<script>
	import commonHeaderVue from '../components/commonHeader.vue';
	export default{
		name:"order",
		components:{
			commonHeaderVue
		},
		methods:{
			createOrder(e){
				alert("点击了添加按钮"+e)
				//.....
			}
		}
	}
</script>

<style>
</style>