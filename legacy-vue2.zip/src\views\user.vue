<template>
	<div @click="">
		<common-header-vue @create="createUser" title="用户管理界面"></common-header-vue>
		<p>{{title}}</p>
		<el-table :data="list" style="width: 100%">
			<el-table-column prop="date" label="日期" width="180">
			</el-table-column>
			<el-table-column prop="name" label="姓名" width="180">
			</el-table-column>
			<el-table-column prop="address" label="地址">
			</el-table-column>
		</el-table>
	</div>
</template>

<script>
	import commonHeaderVue from '../components/commonHeader.vue';
	export default {
		name: "user",
		components: {
			commonHeaderVue
		},
		data() {
			return {
				list:[],
				title:""
			}
		},
		methods: {
			createUser(e) {
				alert("点击了添加按钮" + e)
			},
			async getUserList(){
				//发起一个请求，获取数据
				// const axios = require('axios').default;
				// axios.post("http://localhost:8080/demo/TestServlet",{
				// 	username:"张三",
				// 	pwd:"123456"
				// }).then((res)=>{
				// 	console.log(res);
				// 	this.title=res.data;
				// })
				let res = await this.$api.user.getUserList();
				this.title = res.data;
				console.log(res);
			}
		},
		mounted() {
			this.getUserList();
		}
	}
</script>

<style>
</style>