<template>
	<div>
		这个是注册页面
	</div>
</template>

<script>
	export default{
		name:"register",
		data() {
			return {
				
			}
		},
		methods:{
			
		}
	}
</script>

<style>
</style>