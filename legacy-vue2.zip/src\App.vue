<template>
	<div id="app">
		<router-view></router-view>
	</div>
</template>

<script>
	export default {
		name: 'app',
		//定义值
		data() {
			return {
				name: "张珊",
				person: {},
				list: [{
						name: "张珊"
					},
					{
						name: "李四"
					},
					{
						name: "王五"
					} //"","李四","王五"
				],
				html: "<a href='https://www.baidu.com'>百度一下</a>",
				show: true,
				username: ""
			}
		},
		//定义方法
		methods: {
			toLogin() {
				this.$router.push("/login")			
			},
			toRegister(){
				this.$router.push("/register")	
			},
			changeName() {
				console.log(this.username, "++++++++++++");
				this.person.name = "李四"
				this.name = "李四"
				this.show = false
			},
			getName() {
				console.log(this, "当前对象");
			}
		}
	}
</script>

<style>
	#app {
		font-family: 'Avenir', Helvetica, Arial, sans-serif;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
	}
</style>