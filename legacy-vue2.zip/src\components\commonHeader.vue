<template>
  <div class="common-header">
    <!-- 左侧标题区域（可通过插槽自定义） -->
    <div class="header-title">
      <slot name="title">{{ title }}</slot>
    </div>

    <!-- 右侧按钮组，水平排列 -->
    <div class="header-btns">
      <button class="btn btn-primary" @click="onCreate">
        <span class="btn-icon">＋</span>新建
      </button>
      <button class="btn btn-import" @click="onImport">
        <span class="btn-icon">↑</span>导入
      </button>
      <button class="btn btn-refresh" :disabled="refreshing" @click="onRefresh">
        <span class="btn-icon" :class="{ spinning: refreshing }">↻</span>{{ refreshing ? '刷新中...' : '刷新' }}
      </button>
      <button class="btn btn-danger" @click="onBatchDelete">
        <span class="btn-icon">🗑</span>批量删除<template v-if="selectedCount > 0">（{{ selectedCount }}）</template>
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CommonHeader',
  props: {
    // 标题文字
    title: {
      type: String,
      default: ''
    },
    // 已选中数量，用于批量删除按钮展示
    selectedCount: {
      type: Number,
      default: 0
    },
    // 刷新按钮的 loading 状态，可由父组件控制
    refreshing: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    onCreate() {
		console.log(this.title);
		this.$emit('create',this.title)
    },
    onImport() {
      this.$emit('import')
    },
    onRefresh() {
      this.$emit('refresh')
    },
    onBatchDelete() {
      if (this.selectedCount === 0) {
        this.$emit('batch-delete-empty')
        return
      }
      this.$emit('batch-delete')
    }
  }
}
</script>

<style scoped>
.common-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 12px;
  padding: 12px 16px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.06);
  box-sizing: border-box;
}

.header-title {
  font-size: 16px;
  font-weight: 500;
  color: #333;
}

/* 按钮组：水平排列 */
.header-btns {
  display: flex;
  align-items: center;
  flex-direction: row;
  gap: 10px;
}

.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  height: 32px;
  padding: 0 14px;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  background: #fff;
  color: #333;
  font-size: 13px;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.2s;
}

.btn:hover:not(:disabled) {
  border-color: #667eea;
  color: #667eea;
}

.btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.btn-icon {
  margin-right: 4px;
  font-size: 13px;
  line-height: 1;
}

/* 新建 */
.btn-primary {
  background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
  border: none;
  color: #fff;
}

.btn-primary:hover:not(:disabled) {
  color: #fff;
  opacity: 0.9;
}

/* 导入 */
.btn-import {
  border-color: #409eff;
  color: #409eff;
}

.btn-import:hover:not(:disabled) {
  background: #ecf5ff;
}

/* 刷新 */
.btn-refresh:hover:not(:disabled) {
  border-color: #67c23a;
  color: #67c23a;
}

/* 批量删除 */
.btn-danger {
  border-color: #f56c6c;
  color: #f56c6c;
}

.btn-danger:hover:not(:disabled) {
  background: #fef0f0;
}

/* 刷新图标旋转动画 */
.spinning {
  display: inline-block;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
</style>
