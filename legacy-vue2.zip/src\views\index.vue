<template>
	<div class="layout">
		<!-- 顶部公共头 -->
		<header class="header">
			<div class="header-left">
				<div class="logo">V</div>
				<h1 class="system-name">后台管理系统</h1>
			</div>
			<div class="header-right">
				<span class="welcome">欢迎，{{ userInfo.name }}</span>
				<div class="user-dropdown" @click="toggleDropdown" v-click-outside="closeDropdown">
					<div class="avatar">{{ userInfo.avatar }}</div>
					<span class="arrow" :class="{ open: dropdownOpen }">▾</span>
					<ul class="dropdown-menu" v-show="dropdownOpen">
						<li @click.stop="handleProfile">个人中心</li>
						<li @click.stop="handleSetting">系统设置</li>
						<li class="divider"></li>
						<li @click.stop="handleLogout">退出登录</li>
					</ul>
				</div>
			</div>
		</header>

		<!-- 主体区域 -->
		<div class="body">
			<!-- 左侧菜单 -->
			<aside class="sidebar" :class="{ collapse: sidebarCollapse }">
				<div class="collapse-btn" @click="sidebarCollapse = !sidebarCollapse">
					{{ sidebarCollapse ? '»' : '«' }}
				</div>
				<ul class="menu">
					<li v-for="item in menus" :key="item.path" class="menu-item"
						:class="{ active: activeMenu === item.path }" @click="selectMenu(item)">
						<span class="menu-icon">{{ item.icon }}</span>
						<span class="menu-text" v-show="!sidebarCollapse">{{ item.name }}</span>
					</li>
				</ul>
			</aside>

			<!-- 右侧内容（表格） -->
			<main class="main">
				<div class="breadcrumb">
					首页 / {{ currentMenuName }}
				</div>

				<div class="content-card">
					<router-view></router-view>
				</div>
			</main>
		</div>
	</div>
</template>

<script>
	export default {
		name: 'IndexPage',
		directives: {
			// 点击外部关闭下拉
			clickOutside: {
				bind(el, binding) {
					el._clickOutside = function(e) {
						if (!el.contains(e.target)) {
							binding.value(e)
						}
					}
					document.addEventListener('click', el._clickOutside)
				},
				unbind(el) {
					document.removeEventListener('click', el._clickOutside)
				}
			}
		},
		data() {
			return {
				userInfo: {
					name: '管理员',
					avatar: 'A'
				},
				dropdownOpen: false,
				sidebarCollapse: false,
				activeMenu: '/user',
				menus: [{
						path: '/user',
						name: '用户管理',
						icon: '👤'
					},
					{
						path: '/role',
						name: '角色管理',
						icon: '🛡'
					},
					{
						path: '/order',
						name: '订单管理',
						icon: '📦'
					},
					{
						path: '/product',
						name: '商品管理',
						icon: '🛒'
					},
					{
						path: '/log',
						name: '操作日志',
						icon: '📋'
					}
				],
				keyword: '',
				statusMap: {
					enabled: '启用',
					disabled: '禁用'
				},
				// 模拟数据
				tableData: [],
				currentPage: 1,
				pageSize: 5
			}
		},
		computed: {
			currentMenuName() {
				const m = this.menus.find(item => item.path === this.activeMenu)
				return m ? m.name : ''
			},
			filteredRows() {
				if (!this.keyword) return this.tableData
				return this.tableData.filter(item =>
					item.name.includes(this.keyword)
				)
			},
			total() {
				return this.filteredRows.length
			},
			totalPages() {
				return Math.max(1, Math.ceil(this.total / this.pageSize))
			},
			pagedRows() {
				const start = (this.currentPage - 1) * this.pageSize
				return this.filteredRows.slice(start, start + this.pageSize)
			}
		},
		watch: {
			keyword() {
				this.currentPage = 1
			}
		},
		created() {
			this.mockData()
		},
		methods: {
			mockData() {
				const types = ['普通', 'VIP', '企业']
				const names = ['张三', '李四', '王五', '赵六', '钱七', '孙八', '周九', '吴十', '郑十一', '王十二']
				const creators = ['管理员', '运营员']
				const arr = []
				for (let i = 1; i <= 28; i++) {
					arr.push({
						id: i,
						name: names[(i - 1) % names.length] + i,
						type: types[i % types.length],
						status: i % 4 === 0 ? 'disabled' : 'enabled',
						createdAt: `2026-09-${String((i % 28) + 1).padStart(2, '0')} 10:00`,
						creator: creators[i % creators.length]
					})
				}
				this.tableData = arr
			},
			selectMenu(item) {
				this.activeMenu = item.path
				this.currentPage = 1
				this.keyword = ''
				this.$router.push(item.path)
			},
			toggleDropdown() {
				this.dropdownOpen = !this.dropdownOpen
			},
			closeDropdown() {
				this.dropdownOpen = false
			},
			handleProfile() {
				alert('进入个人中心')
				this.dropdownOpen = false
			},
			handleSetting() {
				alert('进入系统设置')
				this.dropdownOpen = false
			},
			handleLogout() {
				if (confirm('确认退出登录？')) {
					alert('已退出登录')
					this.dropdownOpen = false
				}
			},
			handleAdd() {
				alert(`新增${this.currentMenuName}`)
			},
			handleSearch() {
				this.currentPage = 1
			},
			handleView(row) {
				alert(`查看：${row.name}`)
			},
			handleEdit(row) {
				alert(`编辑：${row.name}`)
			},
			handleDelete(row) {
				if (confirm(`确认删除「${row.name}」？`)) {
					this.tableData = this.tableData.filter(item => item.id !== row.id)
				}
			}
		}
	}
</script>

<style scoped>
	* {
		box-sizing: border-box;
	}

	.layout {
		display: flex;
		flex-direction: column;
		height: 100vh;
		background: #f0f2f5;
		font-family: 'Avenir', Helvetica, Arial, sans-serif;
		color: #333;
	}

	/* ========== 顶部头 ========== */
	.header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		height: 60px;
		padding: 0 20px;
		background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
		color: #fff;
		box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
	}

	.header-left {
		display: flex;
		align-items: center;
	}

	.logo {
		width: 36px;
		height: 36px;
		background: rgba(255, 255, 255, 0.2);
		border-radius: 8px;
		display: flex;
		align-items: center;
		justify-content: center;
		font-weight: bold;
		font-size: 20px;
		margin-right: 12px;
	}

	.system-name {
		margin: 0;
		font-size: 18px;
		font-weight: 500;
	}

	.header-right {
		display: flex;
		align-items: center;
		gap: 16px;
	}

	.welcome {
		font-size: 14px;
	}

	.user-dropdown {
		position: relative;
		display: flex;
		align-items: center;
		cursor: pointer;
		padding: 4px 8px;
		border-radius: 4px;
	}

	.user-dropdown:hover {
		background: rgba(255, 255, 255, 0.15);
	}

	.avatar {
		width: 32px;
		height: 32px;
		background: #fff;
		color: #667eea;
		border-radius: 50%;
		display: flex;
		align-items: center;
		justify-content: center;
		font-weight: bold;
		margin-right: 6px;
	}

	.arrow {
		font-size: 12px;
		transition: transform 0.2s;
	}

	.arrow.open {
		transform: rotate(180deg);
	}

	.dropdown-menu {
		position: absolute;
		top: 44px;
		right: 0;
		width: 140px;
		margin: 0;
		padding: 6px 0;
		list-style: none;
		background: #fff;
		color: #333;
		border-radius: 6px;
		box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
		z-index: 10;
	}

	.dropdown-menu li {
		padding: 8px 16px;
		font-size: 14px;
		cursor: pointer;
	}

	.dropdown-menu li:hover {
		background: #f5f7fa;
		color: #667eea;
	}

	.dropdown-menu .divider {
		height: 1px;
		margin: 4px 0;
		padding: 0;
		background: #ebeef5;
		cursor: default;
	}

	.dropdown-menu .divider:hover {
		background: #ebeef5;
	}

	/* ========== 主体 ========== */
	.body {
		display: flex;
		flex: 1;
		min-height: 0;
	}

	/* ========== 左侧菜单 ========== */
	.sidebar {
		width: 220px;
		background: #001529;
		color: #fff;
		transition: width 0.2s;
		overflow-y: auto;
	}

	.sidebar.collapse {
		width: 64px;
	}

	.collapse-btn {
		height: 40px;
		line-height: 40px;
		text-align: center;
		cursor: pointer;
		color: rgba(255, 255, 255, 0.65);
		border-bottom: 1px solid #1f2d3d;
		user-select: none;
	}

	.collapse-btn:hover {
		color: #fff;
	}

	.menu {
		list-style: none;
		margin: 0;
		padding: 12px 0;
	}

	.menu-item {
		display: flex;
		align-items: center;
		padding: 12px 20px;
		cursor: pointer;
		font-size: 14px;
		color: rgba(255, 255, 255, 0.75);
		transition: background 0.2s, color 0.2s;
	}

	.menu-item:hover {
		background: #1f2d3d;
		color: #fff;
	}

	.menu-item.active {
		background: #667eea;
		color: #fff;
	}

	.menu-icon {
		width: 24px;
		text-align: center;
		margin-right: 10px;
		font-size: 16px;
	}

	.sidebar.collapse .menu-icon {
		margin-right: 0;
	}

	/* ========== 右侧内容 ========== */
	.main {
		flex: 1;
		padding: 16px;
		overflow-y: auto;
	}

	.breadcrumb {
		font-size: 13px;
		color: #666;
		margin-bottom: 12px;
	}

	.content-card {
		background: #fff;
		border-radius: 8px;
		padding: 16px 20px;
		box-shadow: 0 1px 4px rgba(0, 0, 0, 0.06);
	}

	.card-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-bottom: 14px;
	}

	.card-header h3 {
		margin: 0;
		font-size: 16px;
		font-weight: 500;
	}

	.card-actions {
		display: flex;
		align-items: center;
		gap: 8px;
	}

	.search-input {
		height: 32px;
		padding: 0 10px;
		border: 1px solid #dcdfe6;
		border-radius: 4px;
		outline: none;
		font-size: 13px;
		transition: border-color 0.2s;
	}

	.search-input:focus {
		border-color: #667eea;
	}

	.btn {
		height: 32px;
		padding: 0 14px;
		border: 1px solid #dcdfe6;
		background: #fff;
		border-radius: 4px;
		cursor: pointer;
		font-size: 13px;
		transition: all 0.2s;
	}

	.btn:hover {
		border-color: #667eea;
		color: #667eea;
	}

	.btn-primary {
		background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
		border: none;
		color: #fff;
	}

	.btn-primary:hover {
		opacity: 0.9;
		color: #fff;
	}

	/* ========== 表格 ========== */
	.data-table {
		width: 100%;
		border-collapse: collapse;
		font-size: 14px;
	}

	.data-table thead th {
		background: #fafafa;
		padding: 12px 8px;
		text-align: left;
		font-weight: 500;
		color: #555;
		border-bottom: 1px solid #ebeef5;
	}

	.data-table tbody td {
		padding: 12px 8px;
		border-bottom: 1px solid #ebeef5;
	}

	.data-table tbody tr:hover {
		background: #f5f7fa;
	}

	.status {
		display: inline-block;
		padding: 2px 10px;
		border-radius: 12px;
		font-size: 12px;
	}

	.status.enabled {
		background: #e8f5e9;
		color: #67c23a;
	}

	.status.disabled {
		background: #fef0f0;
		color: #f56c6c;
	}

	.op-link {
		color: #667eea;
		margin-right: 8px;
		cursor: pointer;
		text-decoration: none;
		font-size: 13px;
	}

	.op-link:hover {
		text-decoration: underline;
	}

	.op-link.danger {
		color: #f56c6c;
	}

	.empty {
		text-align: center;
		padding: 40px 0 !important;
		color: #999;
	}

	/* ========== 分页 ========== */
	.pagination {
		display: flex;
		align-items: center;
		justify-content: flex-end;
		gap: 6px;
		margin-top: 16px;
		font-size: 13px;
	}

	.page-info {
		color: #666;
		margin-right: 12px;
	}

	.page-btn {
		min-width: 32px;
		height: 32px;
		padding: 0 8px;
		border: 1px solid #dcdfe6;
		background: #fff;
		border-radius: 4px;
		cursor: pointer;
	}

	.page-btn:hover:not(:disabled) {
		border-color: #667eea;
		color: #667eea;
	}

	.page-btn.active {
		background: #667eea;
		border-color: #667eea;
		color: #fff;
	}

	.page-btn:disabled {
		opacity: 0.5;
		cursor: not-allowed;
	}
</style>