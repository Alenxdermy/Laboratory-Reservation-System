import api from "../index.js"

export default{
	async getUserList(){
		return await api.doPost(`TestServlet`, {}, true)
	},
	async deleteUserList(){
		return await api.doGet(`TestServlet?type='delete'`, {}, true)
	}
}