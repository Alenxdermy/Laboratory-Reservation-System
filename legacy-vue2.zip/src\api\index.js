import axios from "axios";
import Vue from "vue";
import {Message} from "element-ui";

const BASE_URL = "http://localhost:8080/demo/"


const api = axios.create({
  baseURL: BASE_URL,
  timeout: 3600000,  
  headers: {'X-Custom-Header': 'imnu'}
});


api.doGet = (url, headers = {}, warning = true)=>{
	return new Promise(async (resolve,reject)=>{
		let data =await api.get(url,{headers});
		if(data.data.code == 0){
			resolve(data.data);
		}else{
			if(warning){
				Message.error(data.data.message)
			}
		}
		reject(false);
	})
}

api.doPost=(url,params={},headers = {}, warning = true)=>{
	return new Promise(async (resolve,reject)=>{
		let data =await api.post(url,params,{headers});
		if(data.data.code == 0){
			resolve(data.data);
		}else{
			if(warning){
				Message.error(data.data.message)
			}
		}
		reject(false);
	})
}

export default api;