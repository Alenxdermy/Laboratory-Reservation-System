<template>
  <div class="login-page">
    <div class="login-box">
      <div class="login-title">
        <h2>用户登录</h2>
        <p>欢迎使用系统，请登录您的账号</p>
      </div>

      <form class="login-form" @submit.prevent="handleLogin">
        <!-- 用户名 -->
        <div class="form-item">
          <label for="username">用户名</label>
          <input
            id="username"
            type="text"
            v-model.trim="form.username"
            placeholder="请输入用户名"
            autocomplete="username"
            @blur="validateField('username')"
          />
          <p class="error-msg" v-if="errors.username">{{ errors.username }}</p>
        </div>

        <!-- 密码 -->
        <div class="form-item">
          <label for="password">密码</label>
          <div class="password-wrapper">
            <input
              id="password"
              :type="showPassword ? 'text' : 'password'"
              v-model.trim="form.password"
              placeholder="请输入密码"
              autocomplete="current-password"
              @blur="validateField('password')"
            />
            <span
              class="toggle-password"
              :class="{ active: showPassword }"
              @click="showPassword = !showPassword"
            >
              {{ showPassword ? '隐藏' : '显示' }}
            </span>
          </div>
          <p class="error-msg" v-if="errors.password">{{ errors.password }}</p>
        </div>

        <!-- 记住我 / 忘记密码 -->
        <div class="form-options">
          <label class="remember">
            <input type="checkbox" v-model="form.remember" />
            <span>记住我</span>
          </label>
          <a href="javascript:;" class="forget-link" @click="handleForget">忘记密码？</a>
        </div>

        <!-- 登录按钮 -->
        <button class="login-btn" type="submit" :disabled="loading">
          {{ loading ? '登录中...' : '登 录' }}
        </button>

        <p class="error-msg center" v-if="loginError">{{ loginError }}</p>

        <!-- 注册提示 -->
        <p class="register-tip">
          还没有账号？<a href="javascript:;" @click="handleRegister">立即注册</a>
        </p>
      </form>
    </div>
  </div>
</template>

<script>
export default {
  name: 'LoginPage',
  data() {
    return {
      form: {
        username: '',
        password: '',
        remember: false
      },
      errors: {
        username: '',
        password: ''
      },
      showPassword: false,
      loading: false,
      loginError: ''
    }
  },
  methods: {
    // 校验单个字段
    validateField(field) {
      if (field === 'username') {
        if (!this.form.username) {
          this.errors.username = '用户名不能为空'
        } else if (this.form.username.length < 3) {
          this.errors.username = '用户名长度不能少于 3 个字符'
        } else {
          this.errors.username = ''
        }
      }
      if (field === 'password') {
        if (!this.form.password) {
          this.errors.password = '密码不能为空'
        } else if (this.form.password.length < 6) {
          this.errors.password = '密码长度不能少于 6 位'
        } else {
          this.errors.password = ''
        }
      }
    },
    // 校验整个表单
    validateForm() {
      this.validateField('username')
      this.validateField('password')
      return !this.errors.username && !this.errors.password
    },
    // 登录
    handleLogin() {
      this.loginError = ''
      if (!this.validateForm()) {
        return
      }
      this.loading = true
      // 模拟登录请求，实际项目中替换为 axios 等接口调用
      setTimeout(() => {
        // 示例账号：admin / 123456
        if (this.form.username === 'admin' && this.form.password === '123456') {
          alert('登录成功！')
          if (this.form.remember) {
            localStorage.setItem('username', this.form.username)
          } else {
            localStorage.removeItem('username')
          }
        } else {
          this.loginError = '用户名或密码错误（示例账号：admin / 123456）'
        }
        this.loading = false
      }, 800)
    },
    handleForget() {
      alert('请联系管理员重置密码')
    },
    handleRegister() {
      alert('跳转到注册页面')
    }
  },
  mounted() {
    // 记住我：回填用户名
    const saved = localStorage.getItem('username')
    if (saved) {
      this.form.username = saved
      this.form.remember = true
    }
  }
}
</script>

<style scoped>
.login-page {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
}

.login-box {
  width: 380px;
  padding: 40px 36px;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
  box-sizing: border-box;
}

.login-title {
  text-align: center;
  margin-bottom: 28px;
}

.login-title h2 {
  margin: 0 0 8px;
  color: #333;
}

.login-title p {
  margin: 0;
  font-size: 13px;
  color: #999;
}

.form-item {
  margin-bottom: 18px;
}

.form-item label {
  display: block;
  margin-bottom: 6px;
  font-size: 14px;
  color: #555;
}

.form-item input[type='text'],
.form-item input[type='password'] {
  width: 100%;
  height: 40px;
  padding: 0 12px;
  border: 1px solid #dcdfe6;
  border-radius: 6px;
  box-sizing: border-box;
  font-size: 14px;
  outline: none;
  transition: border-color 0.2s;
}

.form-item input:focus {
  border-color: #667eea;
}

.password-wrapper {
  position: relative;
}

.toggle-password {
  position: absolute;
  right: 10px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 12px;
  color: #999;
  cursor: pointer;
  user-select: none;
}

.toggle-password.active {
  color: #667eea;
}

.error-msg {
  margin: 6px 0 0;
  font-size: 12px;
  color: #f56c6c;
}

.error-msg.center {
  text-align: center;
}

.form-options {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 20px;
  font-size: 13px;
}

.remember {
  display: flex;
  align-items: center;
  cursor: pointer;
  color: #666;
}

.remember input {
  margin-right: 4px;
}

.forget-link {
  color: #667eea;
  text-decoration: none;
}

.forget-link:hover {
  text-decoration: underline;
}

.login-btn {
  width: 100%;
  height: 42px;
  border: none;
  border-radius: 6px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: #fff;
  font-size: 16px;
  letter-spacing: 4px;
  cursor: pointer;
  transition: opacity 0.2s;
}

.login-btn:hover {
  opacity: 0.9;
}

.login-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.register-tip {
  margin: 18px 0 0;
  text-align: center;
  font-size: 13px;
  color: #999;
}

.register-tip a {
  color: #667eea;
  text-decoration: none;
}

.register-tip a:hover {
  text-decoration: underline;
}
</style>
