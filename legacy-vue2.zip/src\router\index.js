import Vue from "vue";
import VueRouter from "vue-router";
import login from "../views/login.vue"
import registerVue from "../views/register.vue";
import indexVue from "../views/index.vue";
import userVue from "../views/user.vue";
import orderVue from "../views/order.vue";

Vue.use(VueRouter)

const routes=[
	{
		path:"/index",
		component:indexVue,
		children:[
			{path:"/user",component:userVue},
			{path:"/order",component:orderVue}
		]
	},
	{
		path:"/login",
		component:login
	},
	{
		path:"/register",
		component:registerVue
	},
]

const router = new VueRouter({
	routes
})

export default router;